package sample.Layers;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Game;

public class Layer {
    private ImageView view1;
    private ImageView view2;
    private Group group;
    private int speed;
    private float slowMotionSpeed;





    public Layer(int speed, String url)
    {

        this.speed = speed;
        this.slowMotionSpeed = speed/3f;

        view1 = new ImageView(new Image(url, 1500, 1000, false, false));
        view2 = new ImageView(new Image(url, 1500, 1000, false, false));
        view2.setY(- 1000);

        group = new Group(view1, view2);
    }

    public void Move()
    {
        if(!Game.isSlowmotion()) {
            view1.setY(view1.getY() + speed);
            view2.setY(view2.getY() + speed);
        }
        else {
            view1.setY(view1.getY() + slowMotionSpeed);
            view2.setY(view2.getY() + slowMotionSpeed);
        }

        Check();
    }

    public void Check()
    {
        if(view1.getY() > 1000)
            view1.setY(-1000);
        if(view2.getY() > 1000)
            view2.setY(-1000);
    }

    public Group getGroup()
    {
        return group;
    }
}
