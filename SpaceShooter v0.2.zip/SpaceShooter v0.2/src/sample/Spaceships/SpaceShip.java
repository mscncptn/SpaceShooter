package sample.Spaceships;

import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public abstract class SpaceShip {

    ImageView view;
    Label info;
    int HP;
    Group group;


    public Label getInfo() {
        return info;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

}
