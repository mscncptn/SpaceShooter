package sample.Spaceships;

import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import sample.Bullets.MyBullet;
import sample.Game;
import sample.Menu.Menu;

import java.util.ArrayList;

public class Player extends SpaceShip {

    private String name;
    private ArrayList<MyBullet> bullets = new ArrayList<>();
    private Label ammo;
    private int ammocount;
    private boolean hited = true;
    private int hitcountdown = 0;
    private int score = 0;


    {
        name = "DouchBag";
        ammocount = 30;
        view = new ImageView(new Image("/sample/Pictures/Spaceship.png" , 150, 150, false, false));
        HP = 3;
        group = new Group();
        info = new Label("Lifes: " + HP);
        ammo = new Label("Ammo: " + ammocount);
        ammo.setLayoutX(30);
        ammo.setLayoutY(160);
        ammo.setTextFill(Color.GREEN);
        info.setFont(new Font(16));
        info.setTextFill(Color.GREEN);
        info.setLayoutX(30);
        info.setLayoutY(140);
        group.getChildren().addAll(view, info, ammo);
        name = Menu.getName();
    }

    public Player()
    {
        reloc();
    }


    public void Shoot()
    {
        if (ammocount > 0) {
            ammocount  -= 1;
            bullets.add(new MyBullet((int)group.getLayoutX() + 50 ,(int)group.getLayoutY()));
            ammo.setText("Ammo: " + ammocount);
        }

    }

    public void move(double x, double y)
    {
        group.setLayoutX(x);
        group.setLayoutY(y);
    }

    public void addPoints(int i)
    {
        score += i;
    }

    public int getScore()
    {
        return score;
    }

    private void reloc()
    {
        group.setLayoutY(700);
        group.setLayoutX(700);
    }

    public void Hitcheck()
    {
        for(int i = 0; i < Game.enemies.size(); i++)
        {
            if (group.getBoundsInParent().intersects(Game.enemies.get(i).getView().getLayoutBounds()) && !hited)
            {
                hit();
                Game.enemies.get(i).delete();
                System.out.println("BOYAKA BOOYAKA 619");
            }
        }
        for(int i = 0; i < Game.comets.size(); i++)
        {
            if (group.getBoundsInParent().intersects(Game.comets.get(i).getView().getLayoutBounds()) && !hited)
            {
                hit();
                Game.comets.get(i).delete();
                System.out.println("BOYAKA BOOYAKA 6192");
            }
        }
        for(int i = 0; i < Game.meteors.size(); i++)
        {
            if (group.getBoundsInParent().intersects(Game.meteors.get(i).getView().getLayoutBounds()) && !hited)
            {
                hit();
                Game.meteors.get(i).delete();
                System.out.println("BOYAKA BOOYAKA 6194");
            }
        }
        for(int i = 0; i < Game.enemyBullets.size(); i++)
        {
            if (group.getBoundsInParent().intersects(Game.enemyBullets.get(i).getRec().getLayoutBounds()) && !hited)
            {
                hit();
                Game.enemyBullets.get(i).delete();
                System.out.println("BOYAKA BOOYAKA 6195");
            }
        }
        for(int i = 0; i < Game.items.size(); i++)
        {
            if (group.getBoundsInParent().intersects(Game.items.get(i).getView().getLayoutBounds()))
            {
                Game.items.get(i).buff();
                System.out.println("BOYAKA BOOYAKA 6199999");
            }
        }

    }

    public void minusScore()
    {
        if(score > 0)
        score -= 1;
    }

    public Group getGroup()
    {
        return  group;
    }

    public ArrayList<MyBullet> getBullets()
    {
        return bullets;
    }

    public void addAmmo(int ammo)
    {
        ammocount += ammo;
        this.ammo.setText("Ammo: " + ammocount);
    }

    public void addHealth(int hp)
    {
        HP += hp;
        info.setText("Lifes: " + HP);
    }

    public void hitedAnimation()
    {

        if (hited)
        {
            hitcountdown += 1;
            if (view.isVisible()&& hitcountdown%20 == 0)
            {
                view.setVisible(false);
            }
            else if (!view.isVisible() && hitcountdown%20 == 0)
            {
                view.setVisible(true);
            }
            if (hitcountdown == 180)
            {
                view.setVisible(true);
                hited = false;
                hitcountdown = 0;
            }
        }
    }

    private void hit()
    {
        HP -= 1;
        info.setText("Lifes: " + HP);
        hited = true;
        check();
    }

    private void check()
    {
        if (HP == 0)
        {
            death();
        }
    }

    private void death()
    {
        group.setOpacity(0);
        Game.setGameOver();
    }

    public String getName()
    {
        return name;
    }



}
