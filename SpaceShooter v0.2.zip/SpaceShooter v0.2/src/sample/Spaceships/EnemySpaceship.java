package sample.Spaceships;

import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import sample.Bullets.EnemyBullet;
import sample.Game;

import java.util.Random;

public class EnemySpaceship  extends SpaceShip{

    private int timercount = 0;
    private boolean alive = true;

    public EnemySpaceship()
    {
        Random rnd = new Random();
        HP = 4;
        info = new Label("Lifes: " + HP);
        info.setTextFill(Color.RED);
        view = new ImageView(new Image("/sample/Pictures/Enemy.png", 150, 150, false, false));
        info.setLayoutY(- 20);
        group = new Group();
        group.getChildren().addAll(view, info);
        group.setLayoutX(rnd.nextInt(800));
        group.setLayoutY(-200);
        Game.enemiesGroup.getChildren().add(group);
    }

    ImageView getView()
    {
        return view;
    }

    public void fly()
    {
        group.setLayoutY(group.getLayoutY() + 1);
        if (alive) {
            timercount +=1;
            if ((int)Game.player.getGroup().getLayoutY() - 200 > (int)group.getLayoutY()) {
                group.setLayoutY(group.getLayoutY() + 1);
            }
            if ((int)Game.player.getGroup().getLayoutY() - 200 < (int)group.getLayoutY()){
                group.setLayoutY(group.getLayoutY() - 2);
            }
            if ((int)Game.player.getGroup().getLayoutX() > (int)group.getLayoutX()) {
                group.setLayoutX(group.getLayoutX() + 1);
            }
            if ((int)Game.player.getGroup().getLayoutX() < (int)group.getLayoutX()){
                group.setLayoutX(group.getLayoutX() - 1);
            }
            if (timercount == 150)
                Shoot();
        }
        outCheck();
    }

    private void Shoot()
    {
        Game.enemyBullets.add(new EnemyBullet((int)group.getLayoutX() + 75, (int)group.getLayoutY() + 150));
        Game.enemyBulletsGroup.getChildren().add(Game.enemyBullets.get(Game.enemyBullets.size() - 1).getRec());
        timercount = 0;
    }

    public void hit()
    {
        if(alive) {
            HP -= 1;
            info.setText("Lifes: " + HP);
            check();
        }
    }

    private void check()
    {
        if(HP == 0)
        {
            death();
            Game.player.addPoints(1000);
        }
    }

    private void death()
    {
        info.setText("KIA");
        alive = false;
        view.setImage(new Image("/sample/Pictures/destroyedEnemySpaceship.png", 150, 150, false, false));
    }

    private void outCheck()
    {
        if(group.getLayoutY() > 2000)
        {
            delete();
        }
    }

    void delete()
    {
        Game.enemiesGroup.getChildren().remove(group);
        Game.enemies.remove(this);
    }

    public Group getGroup()
    {
        return group;
    }
}
