package sample.Serialization;

import sample.Scoreboard.Score;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

public class Writer {

    public static void save(ArrayList<Score> scores)
    {
            try {
                File file = new File("D://scores.txt");
                PrintStream fileWriter = new PrintStream(file);
                fileWriter.println(scores.size());
                for (int i = 0; i < scores.size(); i++) {
                   fileWriter.println(scores.get(i).getName());
                   fileWriter.println(scores.get(i).getScore());
                }
                fileWriter.close();
            }
            catch (IOException e){System.out.println("Error");}
    }
}
