package sample.Serialization;

import sample.Scoreboard.Score;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Reader {
    public static ArrayList<Score> read()
    {
        ArrayList<Score> scores = new ArrayList<>();
        FileReader reader;
        String url = "D://scores.txt";
        try {
            File file = new File(url);
            reader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(reader);
            int size = Integer.parseInt(bufferedReader.readLine());
            for(int i = 0; i < size; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    try {
                        String name = bufferedReader.readLine();
                        int score = Integer.parseInt(bufferedReader.readLine());
                        scores.add(new Score(score, name, false));
                    }
                    catch (NumberFormatException n)
                    {
                        System.out.println(n.getMessage());
                    }
                }
            }
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }
        return scores;
    }
}
