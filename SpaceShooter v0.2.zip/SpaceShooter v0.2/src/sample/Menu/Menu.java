package sample.Menu;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import sample.Game;
import sample.Main;

public class Menu {

    private static String name;

    public static Scene start()
    {
        Main.setLocation(false);

            ImageView view = new ImageView(new Image("/sample/Pictures/game.png", 430.5, 150, true, true));

            Label label1 = new Label("Write the name");
            label1.setTextFill(Color.WHITE);

            TextField field = new TextField();
            Button startButton = new Button("Start");
            Button exitButton = new Button("Exit");

            exitButton.setAlignment(Pos.CENTER);

            startButton.setOnAction(event -> {
                name = setName(field);
                Main.stage.setScene(Game.start());
            });

            exitButton.setOnAction(event -> Main.stage.close());



        GridPane grid = new GridPane();

        GridPane.setHalignment(exitButton, Pos.CENTER.getHpos());
        GridPane.setHalignment(label1, Pos.CENTER.getHpos());
        GridPane.setHalignment(startButton, Pos.CENTER.getHpos());

        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 10 , 10));

        Scene scene = new Scene(grid);
        scene.setFill(Color.BLACK);

        grid.add(view, 0, 1);
        grid.add(label1, 0, 2);
        grid.add(field, 0, 3);
        grid.add(startButton, 0 ,4);
        grid.add(exitButton, 0, 5);
        grid.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));
        return scene;
    }

    private static String setName(TextField field)
    {
        return field.getText();
    }

    public static String getName()
    {
        return name;
    }
}
