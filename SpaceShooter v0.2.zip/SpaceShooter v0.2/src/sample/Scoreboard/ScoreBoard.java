package sample.Scoreboard;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import sample.Game;
import sample.Main;
import sample.Serialization.Reader;
import sample.Serialization.Writer;

import java.util.ArrayList;

public class ScoreBoard {

    public static Scene show(Score newScore)
    {
        Game.stopTimer();

        ArrayList<Score> scores = Reader.read();
        addScore(newScore, scores);
        Group group = build(scores);
        Scene scene = new Scene(group, 1000, 1000);
        scene.setFill(Color.BLACK);
        scene.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER)
            {
                Main.stage.setScene(Game.start());
                Writer.save(scores);
            }
        });
        return scene;
    }



    private static Group build(ArrayList<Score> scores)
    {
        Group group = new Group();
        for(int i = 0; i < scores.size(); i++)
        {
            scores.get(i).getGroup().setLayoutY((i + 1) * 50);
            group.getChildren().add(scores.get(i).getGroup());
        }
        return group;
    }

    private static void addScore(Score score, ArrayList<Score> scores)
    {
        for(int i = 0; i < scores.size(); i++)
        {
            if(score.getScore() >= scores.get(i).getScore())
            {
                scores.add(i, score);
                break;
            }
        }
    }
}
