package sample.Scoreboard;

import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Score {

    private String name;
    private int score;
    private Group group;

    public Score(int score, String name, boolean newScore)
    {
        Font font = new Font("Arial", 18);
        this.name = name;
        this.score = score;
        Label label1 = new Label(name);
        Label label2 = new Label(Integer.toString(this.score));
        label1.setLayoutX(200);
        label2.setLayoutX(400);

        label1.setFont(font);
        label2.setFont(font);


        if(newScore) {
            label1.setTextFill(Color.GREEN);
            label2.setTextFill(Color.GREEN);
        }
        else {
            label1.setTextFill(Color.WHITE);
            label2.setTextFill(Color.WHITE);
        }

        group = new Group(label1, label2);
    }

    public String getName()
    {
        return name;
    }

    public int getScore()
    {
        return score;
    }

    Group getGroup()
    {
        return group;
    }
}
