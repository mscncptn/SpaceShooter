package sample;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import sample.Menu.Menu;

public class Main extends Application {

    public static Stage stage = new Stage();
    @Override
    public void start(Stage primaryStage){
        stage.setScene(Menu.start());
        setStageStyle();
        stage.setX(600);
        stage.setY(200);
        stage.show();
    }

    private void setStageStyle()
    {
        stage.initStyle(StageStyle.UNDECORATED);
    }

    public static void setLocation(boolean var)
    {
        if(var)
        {
            stage.setX(500);
            stage.setY(0);
        }
        else
        {
            stage.setX(800);
            stage.setY(300);
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}
