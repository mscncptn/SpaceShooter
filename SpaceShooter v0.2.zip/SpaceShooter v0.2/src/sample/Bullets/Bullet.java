package sample.Bullets;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import sample.Game;

public abstract class Bullet {

        protected Rectangle rec = new Rectangle(6, 16);
        protected final int speed = 10;
        protected final double slowMotionSpeed = 10/3;

        public Bullet(int x, int y)
        {
            rec.setY(y);
            rec.setX(x);
        }

        public void fly()
        {
        }

        protected void outCheck()
        {
        }

        protected void hitCheck()
        {
        }

    public Rectangle getRec() {
        return rec;
    }
}
