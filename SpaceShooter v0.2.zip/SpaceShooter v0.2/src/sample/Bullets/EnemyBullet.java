package sample.Bullets;

import javafx.scene.paint.Color;
import sample.Game;

public class EnemyBullet extends Bullet {

    public EnemyBullet(int x, int y)
    {
        super(x, y);
        rec.setFill(Color.GREEN);
    }


    public void fly()
    {
        if(!Game.isSlowmotion())
            rec.setY(rec.getY() + speed);
        else
            rec.setY(rec.getY() + slowMotionSpeed);
        outCheck();
    }

    protected void outCheck()
    {
        if(rec.getY() > 1800)
        {
            delete();
        }
    }

    public void delete()
    {
        Game.enemyBulletsGroup.getChildren().remove(rec);
        Game.enemyBullets.remove(this);
    }
}
