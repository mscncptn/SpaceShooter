package sample.Bullets;

import javafx.scene.paint.Color;
import sample.Game;

public class MyBullet extends Bullet {

    public MyBullet(int x, int y)
    {
        super(x,y);
       rec.setFill(Color.RED);
       Game.bulletsGroup.getChildren().add(rec);
    }


    @Override
    public void fly()
    {
        if(!Game.isSlowmotion())
            rec.setY(rec.getY() - speed);
        else
            rec.setY(rec.getY() - slowMotionSpeed);
        outCheck();
        hitCheck();
        outCheck();
    }

    @Override
    protected void outCheck()
    {
        if (rec.getY() < -300)
        {
            Game.bulletsGroup.getChildren().remove(rec);
            Game.player.getBullets().remove(this);
        }
    }



    @Override
    protected void hitCheck()
    {
        for (int i = 0; i < Game.comets.size(); i++) {
            if (rec.getLayoutBounds().intersects(Game.comets.get(i).getView().getLayoutBounds())) {
                delete();
                Game.comets.get(i).hit();
                System.out.println("hit");
            }
        }
        for (int i = 0; i < Game.meteors.size(); i++) {
            if (rec.getLayoutBounds().intersects(Game.meteors.get(i).getView().getLayoutBounds())) {
                delete();
                Game.meteors.get(i).hit();
                System.out.println("hit2");
            }

        }
        for (int i = 0; i < Game.enemies.size(); i++) {
            if (rec.getBoundsInParent().intersects(Game.enemies.get(i).getGroup().getBoundsInParent())) {
                delete();
                Game.enemies.get(i).hit();
                System.out.println("hit3");
            }
        }
    }

    private void delete()
    {
        Game.bulletsGroup.getChildren().remove(rec);
        Game.player.getBullets().remove(this);
    }
}
