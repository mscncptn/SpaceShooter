package sample.Items;

import javafx.scene.image.ImageView;
import sample.Game;

public abstract class Item {

    ImageView view;

    abstract public void buff();

    public void fly()
    {
        view.setY(view.getY() + 10);
    }

    protected void delete()
    {
        Game.itemsGroup.getChildren().remove(this.view);
        Game.items.remove(this);
    }

    public ImageView getView() {
        return view;
    }

    protected void addToGroup()
    {
        Game.itemsGroup.getChildren().add(view);
    }
}
