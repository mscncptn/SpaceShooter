package sample.Items;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Game;

import java.util.Random;

public class Ammo extends Item {

    private final int FOR_BUFF = 20;

    public Ammo()
    {
        Random rnd = new Random();
        view = new ImageView(new Image("/sample/Pictures/ammo.png", 100, 100, false, false));
        view.setX(rnd.nextInt(1000));
        view.setY((rnd.nextInt(1000) + 100) * -1);
        addToGroup();
    }

    @Override
    public void buff() {
        Game.player.addPoints(100);
        Game.player.addAmmo(FOR_BUFF);
        delete();
    }
}
