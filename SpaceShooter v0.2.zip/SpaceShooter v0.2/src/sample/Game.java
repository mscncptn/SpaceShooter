package sample;

import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import sample.Bullets.EnemyBullet;
import sample.Items.Ammo;
import sample.Items.Item;
import sample.Items.Repair;
import sample.Layers.Layer;
import sample.Menu.Menu;
import sample.Objects.Meteor;
import sample.Objects.Comet;
import sample.Scoreboard.Score;
import sample.Scoreboard.ScoreBoard;
import sample.Spaceships.EnemySpaceship;
import sample.Spaceships.Player;
import java.util.ArrayList;
import java.util.Random;

public class Game {


    private static Group mainGroup;
    public static Group bulletsGroup;
    public static Group cometsGroup;
    public static Group meteorsGroup;
    public static Group enemyBulletsGroup;
    public static Group enemiesGroup;
    public static Group itemsGroup;
    private static Label score;
    public static Scene scene;
    private static Layer layer1;
    private static Layer layer2;
    public static Player player;
    public static ArrayList<Meteor> meteors;
    public static ArrayList<Comet> comets;
    public static ArrayList<EnemyBullet> enemyBullets;
    public static ArrayList<EnemySpaceship> enemies;
    public static ArrayList<Item> items;
    private static int possibility;
    private static int timing;
    private static AnimationTimer timer;
    private static boolean slowMotion = false;
    private static Random rnd = new Random();
    private static boolean gameOver;
    private static ImageView gameOverScreen = new ImageView(new Image("/sample/Pictures/gameover.png", 1000, 1000, false, false));
    private static int timerTick = 200;

   private static void generate(){
        bulletsGroup = new Group();
        cometsGroup = new Group();
        meteorsGroup = new Group();
        mainGroup = new Group();
        enemyBulletsGroup = new Group();
        enemiesGroup = new Group();
        itemsGroup = new Group();

        gameOver = false;
        layer1 = new Layer(4, "/sample/Pictures/Sloy1.png");
        layer2 = new Layer(10, "/sample/Pictures/Sloy2.png");
        player = new Player();
        meteors = new ArrayList<>();
        comets = new ArrayList<>();
        enemyBullets = new ArrayList<>();
        enemies = new ArrayList<>();
        timing = 0;
        score = new Label("Score: " + player.getScore());
        score.setFont(new Font("Arial", 20));
        score.setTextFill(Color.BLUE);
        gameOverScreen.setOpacity(0);
        items = new ArrayList<>();
    }

    public static Scene start()
    {
        Main.setLocation(true);
        generate();
        mainGroup.getChildren().addAll(layer1.getGroup(),layer2.getGroup());
        mainGroup.getChildren().addAll(player.getGroup(), score);
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {

                //ENEMIES
                for(int i = 0; i < enemies.size(); i++)
                {
                    enemies.get(i).fly();
                }
                for(int i = 0; i < comets.size(); i++)
                {
                    comets.get(i).fly();
                }
                for(int i = 0; i < meteors.size(); i++)
                {
                    meteors.get(i).fly();
                }
                for(int i = 0; i < enemyBullets.size(); i++)
                {
                    enemyBullets.get(i).fly();
                }
                for(int i = 0; i < player.getBullets().size(); i++)
                {
                    player.getBullets().get(i).fly();
                }
                for(int i = 0; i < items.size(); i++)
                {
                    items.get(i).fly();
                }

                score.setText("Score: " + player.getScore());

                if(slowMotion)
                    player.minusScore();



                //BACKGROUNDS
                layer1.Move();
                layer2.Move();


                player.Hitcheck();
                player.hitedAnimation();

                //SPAWN
                timing += 1;
                if (timing == timerTick) {
                    possibility = rnd.nextInt(5);
                    switch (possibility)
                    {
                        case 0:
                            comets.add(new Comet());
                            break;
                        case 1:
                            meteors.add(new Meteor("forward"));
                            break;
                        case 2:
                            enemies.add(new EnemySpaceship());
                            break;
                        case 3:
                            items.add(new Ammo());
                            break;
                        case 4:
                            items.add(new Repair());
                            break;
                    }
                    if (timerTick > 40)
                    {
                        timerTick -= 3;
                    }
                    timing = 0;
                }
            }
        };
        timer.start();
        mainGroup.getChildren().addAll(bulletsGroup, cometsGroup, meteorsGroup, enemiesGroup, enemyBulletsGroup,itemsGroup,gameOverScreen);
        scene = new Scene(mainGroup, 1000, 1000);
        scene.setOnKeyPressed (event -> {
            KeyCode keyCode = event.getCode();
            if(!gameOver) {
                if (keyCode == KeyCode.SPACE) {
                    player.Shoot();
                } else if (keyCode == KeyCode.ESCAPE) {
                    exit();
                } else if (keyCode == KeyCode.S) {
                    slowMotion = !slowMotion;
                }
            }
            else
            {
                if (keyCode == KeyCode.ENTER) {
                    Main.stage.setScene(ScoreBoard.show(new Score(player.getScore(), player.getName(), true)));
                } else if (keyCode == KeyCode.ESCAPE) {
                    exit();
                }
            }
        });
        scene.setOnMouseMoved(event -> {
            if(!gameOver)
            {
                player.move(event.getSceneX(), event.getSceneY());
            }
        });
        scene.setFill(Color.BLACK);
        scene.setCursor(Cursor.NONE);
        return scene;
    }

    public static void stopTimer()
    {
        timer.stop();
    }

    private static void exit()
    {
        stopTimer();
        Main.stage.setScene(Menu.start());
    }

    public static void setGameOver()
    {
        gameOver = true;
        gameOverScreen.setOpacity(1);
    }

    public static boolean isSlowmotion()
    {
        return slowMotion;
    }
}
