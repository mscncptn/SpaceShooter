package sample.Objects;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Game;

import java.util.Random;

public class Comet extends CosmicWaste{

    private ImageView view;
    private int rotatespeed;
    private float rotateSlowMotionSpeed;
    public Comet()
    {
        Random rnd = new Random();
        int a = rnd.nextInt(40);
        view = new ImageView(new Image("/sample/Pictures/Comet.png", 300 + a, 200 + a, false, false));
        rotatespeed = rnd.nextInt(2) + 1;
        rotateSlowMotionSpeed = rotatespeed/3f;
        HP = rnd.nextInt(3) + 1;
        speed = rnd.nextInt(4) + 3;
        slowMotionSpeed = speed/3;
        view.setX(rnd.nextInt(800));
        view.setY(rnd.nextInt(100) * -1 - 200);
        Game.cometsGroup.getChildren().add(this.view);

    }


    @Override
    public void fly()
    {
        if(!Game.isSlowmotion()) {
            view.setRotate(view.getRotate() + rotatespeed);
            view.setY(view.getY() + speed);
        }
        else
        {
            view.setRotate(view.getRotate() + rotateSlowMotionSpeed);
            view.setY(view.getY() + slowMotionSpeed);
        }

        outOfFieldCheck();
    }
    public ImageView getView()
    {
        return view;
    }

    private void outOfFieldCheck()
    {
        if(view.getY() > 2000)
        {
            delete();
        }
    }

    public void destruction()
    {
        Game.meteors.add(new Meteor("right"));
        Game.meteors.add(new Meteor("left"));
        int a = Game.meteors.size();
        Game.meteors.get(a - 1).getView().setX(view.getX());
        Game.meteors.get(a-1).getView().setY(view.getY());
        Game.meteors.get(a - 2).getView().setX(view.getX() + 100);
        Game.meteors.get(a-2).getView().setY(view.getY());
    }

    @Override
    public void hit()
    {
        HP -= 1;
        lifesCheck();
    }

    @Override
    protected void lifesCheck()
    {
        if(HP == 0)
        {
            delete();
            Game.player.addPoints(700);
        }
    }

    @Override
    public void delete()
    {
        destruction();
        Game.cometsGroup.getChildren().remove(this.view);
        Game.comets.remove(this);
    }

}
