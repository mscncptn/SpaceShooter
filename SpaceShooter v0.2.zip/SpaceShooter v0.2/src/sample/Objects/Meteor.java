package sample.Objects;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Game;

import java.util.Random;

public class Meteor extends CosmicWaste{

    private ImageView view;
    private int speed;
    private String direction;

    public Meteor(String direction)
    {
        this.direction = direction;
        this.view = new ImageView(new Image("/sample/Pictures/Meteor.png", 140, 140, true, true));
        Random rnd = new Random();
        speed = rnd.nextInt(12) + 2;
        slowMotionSpeed = speed/3;
        view.setX(rnd.nextInt(800));
        view.setY(rnd.nextInt(100) * -1 - 200);
        Game.meteorsGroup.getChildren().add(this.view);
        HP = 1;
    }


    private void outOfFieldCheck()
    {
        for(int i = 0; i < Game.comets.size(); i++)
        {
            if (Game.comets.get(i).getView().getY() > 1800)
            {
                Game.meteorsGroup.getChildren().remove(Game.comets.get(i).getView());
                Game.comets.remove(i);
            }
        }
    }

    public ImageView getView()
    {
        return view;
    }

    @Override
    public void fly()
    {
        if (!Game.isSlowmotion()) {
           forFly(speed);
        }
        else
        {
            forFly(slowMotionSpeed);
        }
        outOfFieldCheck();
    }

    private void forFly(double speed)
    {
        if (direction == "right") {
            view.setX(view.getX() + (speed / 2));
            view.setY(view.getY() + (speed));
        } else if (direction == "left") {
            view.setX(view.getX() - (speed / 2));
            view.setY(view.getY() + (speed));
        } else if (direction == "forward") {
            view.setY(view.getY() + (speed));
        }
    }

    @Override
    public void hit()
    {
        HP -= 1;
        lifesCheck();
    }

    @Override
    protected void lifesCheck()
    {
        if(HP == 0)
        {
            delete();
            Game.player.addPoints(200);
        }
    }

    @Override
    public void delete()
    {
        Game.meteorsGroup.getChildren().remove(this.view);
        Game.meteors.remove(this);
    }
}
