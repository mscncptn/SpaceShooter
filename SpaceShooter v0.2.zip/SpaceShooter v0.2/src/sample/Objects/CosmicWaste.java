package sample.Objects;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Game;

import java.util.Random;

public abstract class CosmicWaste {

    protected int HP;
    protected ImageView view;
    protected int speed;
    protected double slowMotionSpeed;

    public CosmicWaste()
    {
    }


    public ImageView getView()
    {
        return view;
    }


    abstract void hit();

    abstract protected void lifesCheck();

    abstract protected void delete();

    abstract void fly();

}
